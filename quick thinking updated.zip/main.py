import pygame
import random
from cursor import Cursor
from red import Red
from blue import Blue 
from green import Green
from purple import Purple
from pink import Pink


#basic booleans
click_start = False
run= True 
level_1 = False
level_2 = False
level_3 = False
level_4 = False 
level_5 = False 

#gems list to randomize 
color_gems= ["red", "blue", "green", "purple", "pink"]


pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 25)
pygame.display.set_caption("Quick Thinking!")

#intro messages
introduction= my_font.render("Welcome to Quick thinking", True, (0,0,0))
directions1 = my_font.render("In this game, the background will show (in text) a color you have to collect.You need to pick the right colored gem in a certain time", True, (0,0,0))
directions2 = my_font.render("You need to quickly pick the right gem to advance to the next level", True, (0,0,0))
lose_directions = my_font.render("If you are not quick enough you have to repeat the level",True, (0,0,0))
game_start= my_font.render("click if you are ready to start", True, (0,0,0))


#level messages
level_1_message = my_font.render("You have 10 seconds to click the right color", True, (0,0,0))


# sprites
c= Cursor(200,150)
red= Red(random.randint(0,300),random.randint(0,300))
pink= Pink(random.randint(0,300), random.randint(0,300))
green= Green(random.randint(0,300), random.randint(0,300))
blue = Blue(random.randint(0,300), random.randint(0,300))
purple= Purple(random.randint(0,300), random.randint(0,300))


# set up variables for the display
SCREEN_HEIGHT = 370
SCREEN_WIDTH = 530
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)
r= 70
g= 75
b= 100


while run :
   # --- Main event loop
   ## ----- NO BLIT ZONE START ----- ##
   for event in pygame.event.get():
       # User did something
       if event.type == pygame.QUIT:  # If user clicked close
           run = False



   screen.fill((r,g,b))
# screen.blit(c.image, c.rect)


  

   pygame.display.update()


pygame.quit()